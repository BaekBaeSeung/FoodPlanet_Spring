package com.shopping.mycartest;

/*
스프링을 사용하여 의존 관계를 주입해 보겠습니다.
*/

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.List;

public class CarMain04 {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(CarConfig.class);

        System.out.println("\n@Bean(\"객체이름\")을 사용하는 방식");
        Car avante01 = context.getBean("avante01", Car.class);
        System.out.println(avante01.toString());

        System.out.println("\n@Bean(\"객체이름\")을 사용하는 방식");
        Car sonata01 = context.getBean("sonata01", Car.class);
        System.out.println(sonata01.toString());

        System.out.println("\n메소드 이름을 참조하는 방식");
        Car makeAvante02 = context.getBean("makeAvante02", Car.class);
        System.out.println(makeAvante02.toString());

        System.out.println("\n컬렉션 정보");
        // Object 타입을 강등해야 합니다.
        List<Car> carList = (List<Car>)context.getBean("carlist");
        for(Car bean : carList){
            System.out.println(bean.toString());
        }

        System.out.println("\n사람 정보");
        Person person01 = context.getBean("person01", Person.class);
        System.out.println(person01.toString());
    }
}