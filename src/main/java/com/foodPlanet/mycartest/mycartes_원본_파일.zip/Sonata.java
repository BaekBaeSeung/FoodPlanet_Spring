package com.shopping.mycartest;

import lombok.ToString;

@ToString
public class Sonata implements Car{
    private String name ;
    private int price ;
    private String maker;

    public Sonata(String name, int price, String maker) {
        this.name = name;
        this.price = price;
        this.maker = maker;
    }
}
