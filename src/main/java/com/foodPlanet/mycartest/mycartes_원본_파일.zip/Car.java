package com.shopping.mycartest;

public interface Car {
}
