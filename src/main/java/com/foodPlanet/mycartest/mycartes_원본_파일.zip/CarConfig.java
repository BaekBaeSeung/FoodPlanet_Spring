package com.shopping.mycartest;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration // 이 파일은 스프링이 설정용 파일로 인식합니다.
public class CarConfig {
    // 자바   jsp       스프링
    // 객체   자바bean   bean

    @Bean("avante01")
    public Car makeAvante01(){
        Car mycar = new Avante("아반떼 빨간차", 111,"외관이 이뻐요^^");
        return mycar;
    }

    @Bean("sonata01")
    public Car makeSonata01(){
        Car mycar = new Sonata("소나타 센슈어스", 333,"HYUNDAI 차");
        return mycar;
    }

    @Bean
    public Car makeAvante02(){
        Car mycar = new Avante("아반떼 승용차", 222,"서민의 차");
        return mycar;
    }

    @Bean("carlist")
    public List<Car> carList(){
        List<Car> lists = new ArrayList<>();
        lists.add(this.makeAvante01());
        lists.add(this.makeSonata01());
        lists.add(this.makeAvante02());
        return lists;
    }

    @Bean("person01")
    public Person person(){
        Person person = new Person("이정석", 30, "성별", this.makeAvante01()) ;
        return person ;
    }
}
