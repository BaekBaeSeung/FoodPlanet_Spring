package com.shopping.mycartest;

public class CarMain01 {
    public static void main(String[] args) {
        // 생성자를 이용하여 Constructor Injection을 수행하고 있습니다.
        Person bean = new Person("김철수", 25, "남자");
        System.out.println(bean.toString());
    }
}
