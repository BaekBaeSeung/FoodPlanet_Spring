package com.shopping.mycartest;

/*
이전 예시에서 강한 결합(tight coupling)을 살펴 보았습니다. 강한 결합을 약한 결합으로 바꾸는 방법은 해당 클래스 외부에서 미리 객체 생성 후 값을 대입한 다음 생성자 또는 setter 메소드를 이용하여 대입하는 방법입니다.
*/
public class CarMain02 {
    public static void main(String[] args) {
        Avante avante = new Avante() ;

        // setter Injection : 세터를 통한 데이터 입력(write)
        avante.setName("아반떼 검은차");
        avante.setPrice(200);
        avante.setComment("편안해요.");

        // loose coupling(약한 결합) : 객체를 외부에서 생성하여 생성자/셋터를 이용한 주입 방식을 의미합니다.
        // constructor injection
        // computer 객체를 생성하고, 이를 생성자를 통하여 주입(Injection) 시키고 있습니다.
        Person bean = new Person("박영희", 30, "여자", avante);
        System.out.println(bean.toString());
    }
}
