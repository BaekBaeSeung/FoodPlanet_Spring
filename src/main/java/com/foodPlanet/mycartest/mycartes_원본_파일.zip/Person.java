package com.shopping.mycartest;

import lombok.ToString;

@ToString
public class Person {
    private String name ;
    private int age ;
    private String gender ;

    // 의존(Dependency) : 하나의 클래스가 다른 클래스를 참조하고 있는 관계
    // 의존은 변경에 의하여 영향을 받는 관계입니다.
    private Avante avante ;

    // 생성자(constructor) Injection : 생성자를 이용하여 외부에서 데이터를 입력 받고 있습니다.
    public Person(String name, int age, String gender) { // 생성자 01
        this.name = name ;
        this.age = age ;
        this.gender = gender ;

        // 생성자에서 직접 객체를 구하고 있습니다.
        // Person 객체가 생성이 될때 의존 대상인 Avante 객체도 동시에 객체가 생성이 됩니다.
        // 이러한 기법은 즉시 코딩하기에 유리하지만, 유지 보수 관점에서는 다소 불리(차후 살펴볼 예정)합니다.
        // 강한 결합(tight coupling) : 특정 클래스 내에서 다른 클래스에 대한 객체를 직접 생성하고, 값도 직접 대입하는 결합 방식을 의미합니다.
        this.avante = new Avante() ;

        // setter Injection : 세터를 통한 데이터 입력(write)
        this.avante.setName("아반떼 흰차");
        this.avante.setPrice(100);
        this.avante.setComment("차량이 이쁩니다.");

    }

    // 생성자 02
    // 생성자 01에 비하여 결합도가 약해졌습니다.
    public Person(String name, int age, String gender, Avante avante) {
        this.name = name ;
        this.age = age ;
        this.gender = gender ;
        this.avante = avante ;
    }

    private Car car ;

    // 생성자 03
    // 생성자 02에 비하여 결합도가 더 약해졌습니다.
    // 차량의 유무에 상관 없이 대표 이름으로 입력을 받으므로 확장성과 재사용성이 좋아집니다.
    public Person(String name, int age, String gender, Car car) {
        this.name = name ;
        this.age = age ;
        this.gender = gender ;
        this.car = car ;
    }
}
