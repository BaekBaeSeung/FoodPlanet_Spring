package com.shopping.mycartest;

import lombok.Setter;
import lombok.ToString;

@Setter @ToString
public class Avante implements Car {
    private String name ;
    private int price ;
    private String comment ;

    public Avante() {
    }

    public Avante(String name, int price, String comment) {
        this.name = name;
        this.price = price;
        this.comment = comment;
    }
}
